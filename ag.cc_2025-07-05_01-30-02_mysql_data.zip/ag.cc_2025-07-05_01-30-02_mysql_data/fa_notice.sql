-- MySQL dump 10.13  Distrib 5.7.43, for Linux (x86_64)
--
-- Host: localhost    Database: ag.cc
-- ------------------------------------------------------
-- Server version	5.7.43-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fa_notice`
--

DROP TABLE IF EXISTS `fa_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_notice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `category_id` varchar(32) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `jumplink` text COMMENT '跳转链接',
  `content` mediumtext NOT NULL COMMENT '内容',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '封面图',
  `is_top` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` enum('normal','hidden') NOT NULL DEFAULT 'normal' COMMENT '状态',
  `pubtime` int(10) unsigned DEFAULT NULL COMMENT '发布时间',
  `createtime` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(10) unsigned DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `pubtime` (`pubtime`),
  KEY `is_top` (`is_top`),
  KEY `sort` (`sort`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='公告表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_notice`
--

LOCK TABLES `fa_notice` WRITE;
/*!40000 ALTER TABLE `fa_notice` DISABLE KEYS */;
INSERT INTO `fa_notice` VALUES (1,'rollingNotification','提现提示-滚动形式通知','','2423432','/uploads/20250423/57ab2de862df1955c37db76975c00b8b.jpg',0,0,'normal',1745410127,1745410135,1745485248),(2,'active','活动公告1','http://sdsdss','<p><img src=\"http://ag.cc/uploads/20250423/fb0624f5a446f3f82ed6e081887b2f5e.jpg\" data-filename=\"filename\" style=\"width: 267px;\"><br></p>','/uploads/20250423/6287a2c2dc915e2e931156c3cfa0e019.jpg',0,0,'normal',1745412599,1745412681,1745485231),(3,'system','系统公告1','http://sdsdss','<p>系统公告系统公告系统公告系统公告</p>','/uploads/20250424/6287a2c2dc915e2e931156c3cfa0e019.jpg',0,0,'normal',1745485252,1745485276,1745485276),(4,'system','系统公告2','http://sdsdss','<p>3423423</p>','/uploads/20250424/bb35f50a1bba5f1c915d7101143553dd.jpg',0,0,'normal',1745485282,1745485298,1745485298),(5,'active','活动公告2','http://sdsdss','<p>活动公告活动公告活动公告活动公告二十二</p>','/uploads/20250424/fb0624f5a446f3f82ed6e081887b2f5e.jpg',0,0,'normal',1745485301,1745485320,1745485320);
/*!40000 ALTER TABLE `fa_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ag.cc'
--

--
-- Dumping routines for database 'ag.cc'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-05  1:30:03
