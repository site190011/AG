-- MySQL dump 10.13  Distrib 5.7.43, for Linux (x86_64)
--
-- Host: localhost    Database: ag.cc
-- ------------------------------------------------------
-- Server version	5.7.43-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fa_user_recharge`
--

DROP TABLE IF EXISTS `fa_user_recharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_user_recharge` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `order_no` varchar(64) NOT NULL DEFAULT '' COMMENT '订单号',
  `audit_type` varchar(32) NOT NULL DEFAULT '' COMMENT '审核方式',
  `transaction_image` varchar(255) NOT NULL DEFAULT '' COMMENT '交易凭证',
  `amount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '充值金额',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态(0:待支付,1:成功,2:失败)',
  `currency` varchar(32) NOT NULL DEFAULT '' COMMENT '币种',
  `bank_id` int(11) NOT NULL DEFAULT '0' COMMENT '支付渠道ID',
  `is_first` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否首次充值',
  `pay_method` varchar(20) DEFAULT '' COMMENT '支付方式',
  `transaction_id` varchar(64) DEFAULT '' COMMENT '第三方交易号',
  `remark` text COMMENT '备注',
  `notify_data` text COMMENT '支付回调数据',
  `success_time` int(11) NOT NULL DEFAULT '0' COMMENT '成功时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COMMENT='用户充值表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_user_recharge`
--

LOCK TABLES `fa_user_recharge` WRITE;
/*!40000 ALTER TABLE `fa_user_recharge` DISABLE KEYS */;
INSERT INTO `fa_user_recharge` VALUES (1,2,'222','manual','',660.00,1,'',0,0,'','33','','',1749737358,'2025-06-12 20:55:46','2025-06-12 20:55:46'),(2,13,'adsdadasda','','',9999.00,1,'',0,0,'','vx',NULL,'',0,'2025-06-22 01:03:37','2025-06-22 01:03:37'),(4,2,'2223','','',10.00,0,'',0,0,'','33',NULL,'',0,'2025-06-22 01:10:50','2025-06-22 01:10:50'),(5,2,'6856eef46a79d','manual','',30.00,0,'',0,0,'system','','后台添加充值',NULL,0,'2025-06-22 01:42:12','2025-06-22 01:42:12'),(6,3,'6856f14ee0dbc','manual','',50.00,0,'',0,0,'system','','后台添加充值',NULL,0,'2025-06-22 01:52:14','2025-06-22 01:52:14'),(7,2,'6856f2adc88ae','manual','',40.00,0,'',0,0,'system','','后台添加充值',NULL,0,'2025-06-22 01:58:05','2025-06-22 01:58:05'),(8,2,'6856f2dd492c5','manual','',40.00,0,'',0,0,'system','','后台添加充值',NULL,0,'2025-06-22 01:58:53','2025-06-22 01:58:53'),(9,1,'6856f3079e340','manual','',10.00,0,'',0,0,'system','','后台添加充值',NULL,0,'2025-06-22 01:59:35','2025-06-22 01:59:35'),(10,2,'6856f3997a80c','manual','',40.00,0,'',0,0,'system','','后台添加充值',NULL,0,'2025-06-22 02:02:01','2025-06-22 02:02:01'),(11,1,'6856f3dfc7faa','manual','',10.00,0,'',0,0,'system','','后台添加充值',NULL,0,'2025-06-22 02:03:11','2025-06-22 02:03:11'),(12,2,'6856f543a303c','manual','',30.00,0,'',0,0,'system','','后台添加充值',NULL,0,'2025-06-22 02:09:07','2025-06-22 02:09:07'),(13,2,'6856f5788e886','manual','',30.00,0,'',0,0,'system','','后台添加充值',NULL,0,'2025-06-22 02:10:00','2025-06-22 02:10:00'),(14,2,'6856f5a792dc3','manual','',10.00,0,'',0,0,'system','','后台添加充值',NULL,0,'2025-06-22 02:10:47','2025-06-22 02:10:47'),(15,2,'6856f60eede54','manual','',20.00,0,'',0,0,'system','','后台添加充值',NULL,0,'2025-06-22 02:12:30','2025-06-22 02:12:30'),(16,2,'6856f6724f687','manual','',50.00,0,'',0,0,'system','','后台添加充值',NULL,0,'2025-06-22 02:14:10','2025-06-22 02:14:10'),(17,2,'6856f6af7d2f8','manual','',30.00,0,'',0,0,'system','','后台添加充值',NULL,0,'2025-06-22 02:15:11','2025-06-22 02:15:11'),(18,2,'6856f70940428','manual','',110.00,0,'',0,0,'system','','后台添加充值',NULL,0,'2025-06-22 02:16:41','2025-06-22 02:16:41'),(19,2,'6856f74e2ca11','manual','',20.00,1,'',0,0,'system','','后台添加充值',NULL,1750530806,'2025-06-22 02:17:50','2025-06-22 02:17:50'),(20,2,'6856f77c0d4fe','manual','',10.00,1,'',0,0,'system','','后台添加充值',NULL,1750530781,'2025-06-22 02:18:36','2025-06-22 02:18:36'),(21,2,'6856f7d427c8c','manual','',30.00,1,'',0,0,'system','','后台添加充值',NULL,1750530615,'2025-06-22 02:20:04','2025-06-22 02:20:04'),(22,2,'6856f8419841b','manual','',99.00,1,'',0,0,'system','','后台添加充值',NULL,1750530607,'2025-06-22 02:21:53','2025-06-22 02:21:53'),(23,2,'685a924c457cf','manual','',9999999.00,1,'',0,0,'system','','后台添加充值',NULL,1750766188,'2025-06-24 19:55:56','2025-06-24 19:55:56'),(24,2,'685a937c6423f','manual','',99999.00,1,'',0,0,'system','','后台添加充值',NULL,1750766537,'2025-06-24 20:01:00','2025-06-24 20:01:00'),(25,2,'685a95355d30f','manual','',1.00,1,'',0,0,'system','','后台添加充值',NULL,1750766917,'2025-06-24 20:08:21','2025-06-24 20:08:21'),(26,2,'685a9684219db','manual','',10.00,1,'',0,0,'system','','后台添加充值',NULL,1750767619,'2025-06-24 20:13:56','2025-06-24 20:13:56'),(27,2,'685a98984d8e6','manual','',10.00,1,'',0,0,'system','','后台添加充值',NULL,1750767782,'2025-06-24 20:22:48','2025-06-24 20:22:48'),(30,9,'685ad57fa1ce3','manual','/path/xxx.jpg',9999.00,1,'cny',11,0,'user_pay','','',NULL,1750783417,'2025-06-25 00:42:39','2025-06-25 00:42:39'),(31,9,'685ad58698245','manual','/path/xxx.jpg',9999.00,1,'cny',11,0,'user_pay','','',NULL,1750783425,'2025-06-25 00:42:46','2025-06-25 00:42:46'),(32,9,'685ad6dc87d72','manual','/path/xxx.jpg',9999.00,0,'cny',11,0,'user_pay','',NULL,NULL,0,'2025-06-25 00:48:28','2025-06-25 00:48:28'),(33,13,'685adb4887c85','manual','/uploads/20250624/ca817322091b2b45e4e8030bb05b9c52.png',2432.00,1,'cny',3,0,'user_pay','','',NULL,1750785453,'2025-06-25 01:07:20','2025-06-25 01:07:20'),(34,14,'68604edc08a16','manual','/uploads/20250629/44a5af940020929cf035e504d02a9665.jpg',1000.00,1,'cny',1,0,'user_pay','','',NULL,1751142364,'2025-06-29 04:21:48','2025-06-29 04:21:48'),(35,13,'6860641048ca5','manual','/uploads/20250629/d55017c7d9bea9b9c37a2f543070f1d6.png',1000.00,1,'cny',1,0,'user_pay','','',NULL,1751147557,'2025-06-29 05:52:16','2025-06-29 05:52:16'),(36,13,'6860646bb06a2','manual','/uploads/20250629/53399945c9eb7d8545fbaa161176786d.jpg',10000.00,1,'cny',1,0,'user_pay','','',NULL,1751147640,'2025-06-29 05:53:47','2025-06-29 05:53:47'),(37,11,'68679b2f4e794','manual','',10.00,1,'',0,0,'system','','后台添加充值',NULL,1751620421,'2025-07-04 17:13:19','2025-07-04 17:13:19'),(38,21,'68679fc2ebbda','manual','',20.00,1,'',0,0,'system','','后台添加充值',NULL,1751621592,'2025-07-04 17:32:50','2025-07-04 17:32:50');
/*!40000 ALTER TABLE `fa_user_recharge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ag.cc'
--

--
-- Dumping routines for database 'ag.cc'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-05  1:30:04
