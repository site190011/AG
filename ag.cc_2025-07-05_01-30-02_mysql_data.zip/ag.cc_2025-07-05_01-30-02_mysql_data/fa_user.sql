-- MySQL dump 10.13  Distrib 5.7.43, for Linux (x86_64)
--
-- Host: localhost    Database: ag.cc
-- ------------------------------------------------------
-- Server version	5.7.43-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fa_user`
--

DROP TABLE IF EXISTS `fa_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '组别ID',
  `pid` int(11) DEFAULT '0',
  `pid_path` varchar(255) DEFAULT '0,',
  `playerIds` json DEFAULT NULL,
  `username` varchar(32) DEFAULT '' COMMENT '用户名',
  `nickname` varchar(50) DEFAULT '' COMMENT '昵称',
  `password` varchar(32) DEFAULT '' COMMENT '密码',
  `salt` varchar(30) DEFAULT '' COMMENT '密码盐',
  `email` varchar(100) DEFAULT '' COMMENT '电子邮箱',
  `mobile` varchar(11) DEFAULT '' COMMENT '手机号',
  `avatar` varchar(255) DEFAULT '' COMMENT '头像',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '等级',
  `viplevel` int(11) NOT NULL DEFAULT '0' COMMENT 'VIP等级',
  `gender` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` varchar(32) DEFAULT NULL COMMENT '生日',
  `bio` varchar(100) DEFAULT '' COMMENT '格言',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总余额',
  `in_games` json DEFAULT NULL COMMENT '当前在玩哪些游戏	',
  `score` int(10) NOT NULL DEFAULT '0' COMMENT '积分',
  `successions` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '连续登录天数',
  `maxsuccessions` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '最大连续登录天数',
  `prevtime` bigint(16) DEFAULT NULL COMMENT '上次登录时间',
  `logintime` bigint(16) DEFAULT NULL COMMENT '登录时间',
  `loginip` varchar(50) DEFAULT '' COMMENT '登录IP',
  `loginfailure` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '失败次数',
  `loginfailuretime` bigint(16) DEFAULT NULL COMMENT '最后登录失败时间',
  `joinip` varchar(50) DEFAULT '' COMMENT '加入IP',
  `jointime` bigint(16) DEFAULT NULL COMMENT '加入时间',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `token` varchar(50) DEFAULT '' COMMENT 'Token',
  `status` varchar(30) DEFAULT '' COMMENT '状态',
  `verification` varchar(255) DEFAULT '' COMMENT '验证',
  `pay_password` varchar(32) DEFAULT NULL COMMENT '支付密码',
  `extra` text COMMENT '额外的信息',
  `agent_promotion` tinyint(1) DEFAULT '0' COMMENT '是否合营代理',
  `invitation_code` varchar(32) NOT NULL DEFAULT '' COMMENT '邀请码',
  `invitation_uid` int(11) NOT NULL DEFAULT '0' COMMENT '邀请人',
  `online_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `email` (`email`),
  KEY `mobile` (`mobile`),
  KEY `agent_promotion` (`agent_promotion`),
  KEY `pid` (`pid`),
  KEY `pid_path` (`pid_path`),
  KEY `online_time` (`online_time`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COMMENT='会员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_user`
--

LOCK TABLES `fa_user` WRITE;
/*!40000 ALTER TABLE `fa_user` DISABLE KEYS */;
INSERT INTO `fa_user` VALUES (1,1,0,'0,',NULL,'admin','admin','99152baa12771bd29bd95fefa05f984c','f7d11c','admin@163.com','13000000000','/assets/img/avatar.png',0,0,0,'2017-04-08','',9999.00,NULL,0,1,1,1491635035,1491635035,'127.0.0.1',0,1491635035,'127.0.0.1',1491635035,0,1747840894,'','normal','',NULL,NULL,0,'',0,0),(2,1,0,'0','{\"ap\": \"p00002\", \"fc\": \"p00002\", \"im\": \"p00002\", \"mg\": \"p00002\", \"mt\": \"p00002\", \"nw\": \"p00002\", \"pg\": \"p00002\", \"pt\": \"p00002\", \"ss\": \"p00002\", \"tf\": \"p00002\", \"wl\": \"p00002\", \"xj\": \"p00002\", \"cq9\": \"p00002\", \"db3\": \"p00002\", \"leg\": \"p00002\", \"lgd\": \"p00002\", \"yoo\": \"p00002\", \"bbin\": \"p00002\", \"saba\": \"p00002\", \"joker\": \"p00002\", \"newbb\": \"p00002\", \"panda\": \"p00002\"}','test001','test001','60005be82dc40d8c76b019b6b913d537','okyx8N','site88550@gmail.com','','y',1,9,0,'2025-06-05','',119020.00,'{\"yoo\": {\"time\": 1751226241, \"money\": \"118020.00\", \"gameId\": \"6046\"}}',0,1,7,1750354684,1750534612,'160.30.128.177',0,1750534597,'127.0.0.1',1745397318,1745397318,1751226241,'','normal','','111111',NULL,1,'',0,1751573263),(3,0,2,'0,2,',NULL,'test002','test002','d64b6658391670be52e8ca883410edf1','Gbf4Uc','','','',1,1,0,NULL,'',1100.00,NULL,0,1,1,1750353516,1751457780,'47.251.156.29',0,NULL,'127.0.0.1',1745397651,1745397651,1751457780,'828e7666-373c-4542-9c81-be3dcefe3ad7','normal','',NULL,NULL,1,'',0,0),(4,0,3,'0,2,3,',NULL,'2_682f3b92a2900','','37ecaec27110e45a8d9c889d503b5e31','682f3b92a2902','','','',0,2,0,NULL,'',0.00,NULL,0,1,1,NULL,NULL,'',0,NULL,'',1747925906,NULL,NULL,'','','',NULL,NULL,0,'',0,0),(5,0,4,'0,2,3,4',NULL,'2_682f3bba38736','','d1ab9d4f905a19349c1fdac4629c53a2','682f3bba38747','','','',0,3,0,NULL,'',1.80,NULL,0,1,1,NULL,NULL,'',0,NULL,'',1747925946,NULL,1749023405,'','','',NULL,NULL,0,'',0,0),(6,0,2,'0,2,',NULL,'2_682f3c79','','1ad13684c2946b30cc90abdafe15cb08','682f3c79','','','',0,0,0,NULL,'',0.00,NULL,0,1,1,NULL,NULL,'',0,NULL,'',1747926137,NULL,NULL,'','normal','',NULL,NULL,0,'',0,0),(7,0,2,'0,2,',NULL,'2_682f3f51','','e15898568848aa6df8e68507a4819c21','682f3f51','','','',0,0,0,NULL,'',0.00,NULL,0,1,1,NULL,NULL,'',0,NULL,'',1747926865,NULL,NULL,'','normal','',NULL,NULL,0,'',0,0),(8,0,2,'0,2,',NULL,'2_683bd5d0','','e575d66bd59a362e1a7f82a9d01b8264','683bd5d0','','','',0,0,0,NULL,'',0.00,NULL,0,1,1,NULL,NULL,'',0,NULL,'',1748751824,NULL,NULL,'','normal','',NULL,NULL,0,'',0,0),(9,0,0,'0',NULL,'testuser','测试用户','1a70562c8ae94b481aa44bdb0e760625','2VHICs','test@test.com','13800138000','',1,7,0,NULL,'',28998.00,NULL,0,1,1,1749968875,1749969280,'47.89.151.48',0,NULL,'47.89.151.48',1749968875,1749968875,1750783425,'','normal','',NULL,NULL,0,'',0,1751266616),(10,0,0,'0,',NULL,'testuser1','testuser1','6fecd31b77e35407337de131ef48c3f8','H9ejXz','','','',1,0,0,NULL,'',0.00,NULL,0,1,1,1750068216,1750068216,'47.89.151.48',0,NULL,'47.89.151.48',1750068216,1750068216,1750068216,'','normal','',NULL,NULL,0,'0VG7WB',0,0),(11,0,0,'0,',NULL,'testuser2','testuser2','b13a137dfdf9fdca55197833e0471476','Upjvsz','','','',1,1,0,NULL,'',2010.00,NULL,0,1,1,1750069142,1750069142,'47.89.151.48',0,NULL,'47.89.151.48',1750069142,1750069142,1751620421,'','normal','',NULL,NULL,0,'UQLKYJ',0,0),(12,0,0,'0,',NULL,'testuser4','testuser4','4c5a09d9a9ddc79b6606d83435424e4f','jJHnhu','','','',1,0,0,NULL,'',0.00,NULL,0,1,1,1750069217,1750069217,'47.89.151.48',0,NULL,'47.89.151.48',1750069217,1750069217,1750069217,'','normal','',NULL,NULL,0,'SXLOWP',10,0),(13,1,0,'0,','{\"mg\": \"p000013\", \"wl\": \"p000013\", \"db2\": \"p000013\", \"lgd\": \"p000013\"}','zxc123','dadada','4633605a71fe1d2e8dcaa5d12cebcf61','qIYQGV','dhjakhdkj@gmail.com','12343223456','',1,7,1,'2025-06-24','',22432.00,'{\"mg\": {\"time\": 1750705289, \"money\": \"100.00\", \"gameId\": \"3341\"}}',0,1,6,1751362589,1751571502,'154.84.135.62',0,NULL,'160.30.128.179',1750488080,1750488080,1751571502,'','normal','','123456',NULL,0,'SP4CEN',1,1751575158),(14,0,0,'0,','{\"pp\": \"p00014\", \"pt\": \"p00014\", \"cq9\": \"p00014\", \"lgd\": \"p00014\"}','qwe9900','qwe9900','f8aa8f9f27c19e011ea79d6c483680db','RyG4m5','','','',1,1,0,NULL,'',4000.00,'{\"pp\": {\"time\": 1751142764, \"money\": \"2000.00\", \"gameId\": \"4096\"}}',0,1,1,1750540148,1751142001,'103.178.57.28',0,NULL,'103.178.57.28',1750538672,1750538672,1751142764,'','normal','',NULL,NULL,0,'R7TPSJ',1,1751142761),(15,0,0,'0,',NULL,'qwer9090','qwer9090','71b8985a6e40e955139b62cd1a5c2067','MN2b50','','','',1,0,0,NULL,'',0.00,NULL,0,1,1,1750554112,1750554159,'103.178.57.28',0,NULL,'103.178.57.28',1750554044,1750554044,1750554159,'','normal','',NULL,NULL,0,'SJOTRT',1,0),(16,0,0,'0,',NULL,'3333','eeee','','','','','',0,0,0,NULL,'',0.00,NULL,0,1,1,NULL,NULL,'',0,NULL,'',NULL,NULL,1751562207,'','normal','',NULL,NULL,0,'',0,0),(17,0,0,'0,',NULL,'4444','','','','','','',0,0,0,NULL,'',0.00,NULL,0,1,1,NULL,NULL,'',0,NULL,'',NULL,NULL,1751562354,'','normal','',NULL,NULL,0,'',0,0),(20,0,3,'0,2,,3',NULL,'5556','','','','','','',0,0,0,NULL,'',0.00,NULL,0,1,1,NULL,NULL,'',0,NULL,'',NULL,NULL,1751562768,'','normal','',NULL,NULL,0,'',0,0),(21,0,3,'0,2,3,',NULL,'666','3333','','','site8855022@gmail.com','','',0,1,0,NULL,'',2020.00,NULL,0,1,1,NULL,NULL,'',0,NULL,'',NULL,NULL,1751621592,'','normal','',NULL,NULL,0,'',0,0),(22,0,3,'0,2,3,',NULL,'555','333','','','site885503@gmail.com','','',0,0,0,NULL,'',0.00,NULL,0,1,1,NULL,NULL,'',0,NULL,'',NULL,NULL,1751615147,'','normal','',NULL,NULL,0,'',0,0),(23,0,3,'0,2,3,',NULL,'5555','eee5','42e6ba62cf538f447046bc71cdbf954e','4RoigH','site885502@gmail.com','','',0,0,0,NULL,'',0.00,NULL,0,1,1,NULL,NULL,'',0,NULL,'47.251.156.29',1751563565,NULL,1751596631,'','normal','',NULL,NULL,1,'JE1VFT',3,0);
/*!40000 ALTER TABLE `fa_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ag.cc'
--

--
-- Dumping routines for database 'ag.cc'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-05  1:30:04
