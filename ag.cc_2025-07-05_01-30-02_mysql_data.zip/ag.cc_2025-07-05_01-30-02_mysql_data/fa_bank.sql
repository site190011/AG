-- MySQL dump 10.13  Distrib 5.7.43, for Linux (x86_64)
--
-- Host: localhost    Database: ag.cc
-- ------------------------------------------------------
-- Server version	5.7.43-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fa_bank`
--

DROP TABLE IF EXISTS `fa_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_bank` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '银行ID',
  `type` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '类型',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '银行全称（如：中国工商银行）',
  `short_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '银行简称（如：工行）',
  `bank_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '银行编码（如：ICBC）',
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行Logo存储路径',
  `qr_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sort` tinyint(3) unsigned DEFAULT '100' COMMENT '排序权重',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态（1启用 0停用）',
  `exchange_rate` decimal(10,4) NOT NULL DEFAULT '1.0000' COMMENT '与人民币的汇率',
  `is_recharge_scope` int(11) DEFAULT '1' COMMENT '是否用于充值',
  `is_withdraw_scope` int(11) DEFAULT '1' COMMENT '是否用于提现',
  `config` json DEFAULT NULL COMMENT '配置信息',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_name` (`name`),
  UNIQUE KEY `uniq_code` (`bank_code`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='银行基础信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_bank`
--

LOCK TABLES `fa_bank` WRITE;
/*!40000 ALTER TABLE `fa_bank` DISABLE KEYS */;
INSERT INTO `fa_bank` VALUES (1,'bank','中国工商银行','工行','ICBC','/uploads/20250622/42fdfe46fcc30fd9fd5a3bd9ecd8f215.jpg','',1,1,1.0000,1,1,'{\"bank_name\": \"中国工商银行\", \"branch_name\": \"北京分行\", \"account_name\": \"张三\", \"account_type\": \"储蓄账户\", \"account_number\": \"6222021234567890\"}','2025-05-07 03:02:38','2025-06-22 14:43:01'),(2,'bank','中国农业银行','农行','ABC','/uploads/20250622/3aaaf124161924e63e5c23c025f00a87.jpg','/uploads/20250622/3aaaf124161924e63e5c23c025f00a87.jpg',2,1,1.0000,1,1,'{\"bank_name\": \"中国工商银行\", \"branch_name\": \"北京分行\", \"account_name\": \"张三\", \"account_type\": \"储蓄账户\", \"account_number\": \"6222021234567890\"}','2025-05-07 03:02:38','2025-06-22 14:44:50'),(3,'bank','中国银行','中行','BOC','/uploads/20250622/07229a2401e5b8c3927059af403951d7.png','',3,1,1.0000,1,1,'{\"bank_name\": \"中国工商银行\", \"branch_name\": \"北京分行\", \"account_name\": \"张三\", \"account_type\": \"储蓄账户\", \"account_number\": \"6222021234567890\"}','2025-05-07 03:02:38','2025-06-22 14:48:42'),(4,'bank','中国建设银行','建行','CCB','/uploads/20250622/111e804ccf145c921f830e07376a9bab.jpg','/uploads/20250622/111e804ccf145c921f830e07376a9bab.jpg',4,1,1.0000,1,1,'{\"bank_name\": \"中国工商银行\", \"branch_name\": \"北京分行\", \"account_name\": \"张三\", \"account_type\": \"储蓄账户\", \"account_number\": \"6222021234567890\"}','2025-05-07 03:02:38','2025-06-22 14:49:39'),(5,'bank','交通银行','交行','BCOM','/uploads/20250622/c5edd4387b25b58254fef23a665d0da4.jpg','/uploads/20250622/c5edd4387b25b58254fef23a665d0da4.jpg',5,1,1.0000,1,1,'null','2025-05-07 03:02:38','2025-06-22 14:50:27'),(6,'bank','招商银行','招行','CMB','/uploads/20250622/8bf5e8b61655b4eca9fbb6e2f5fb7f46.jpg','/uploads/20250622/8bf5e8b61655b4eca9fbb6e2f5fb7f46.jpg',6,1,1.0000,1,1,'null','2025-05-07 03:02:38','2025-06-22 14:51:00'),(7,'bank','浦发银行','浦发','SPDB','/uploads/20250622/3a786488a5e659ccbd93b7447694c3a0.jpg','/uploads/20250622/3a786488a5e659ccbd93b7447694c3a0.jpg',7,1,1.0000,1,1,'null','2025-05-07 03:02:38','2025-06-22 14:51:34'),(8,'bank','兴业银行','兴业','CIB','/uploads/20250622/0a96311b3de8ab8d0986cbddeb83d028.jpg','/uploads/20250622/0a96311b3de8ab8d0986cbddeb83d028.jpg',8,1,1.0000,1,1,'null','2025-05-07 03:02:38','2025-06-22 14:52:08'),(9,'bank','中信银行','中信','CITIC','/uploads/20250622/f87ece61db932ec3c5b1d5087c05abf0.jpg','/uploads/20250622/f87ece61db932ec3c5b1d5087c05abf0.jpg',9,1,1.0000,1,1,'null','2025-05-07 03:02:38','2025-06-22 14:52:41'),(10,'third','支付宝','支付宝','alipay','/uploads/20250622/e05fb7d12c52fc08ed0b83cc9aafaa70.png','/uploads/20250622/e05fb7d12c52fc08ed0b83cc9aafaa70.png',10,1,1.0000,1,1,'null','2025-05-07 03:02:38','2025-06-22 14:53:13'),(11,'virtual','比特币','比特币','BT','/uploads/20250622/e7a60c55353ffd3c97317de12aa5b9e0.jpg','/uploads/20250622/e7a60c55353ffd3c97317de12aa5b9e0.jpg',100,1,30.0000,1,0,'{\"address\": \"xxxxxxxx\"}','2025-05-19 14:55:33','2025-06-22 14:53:42'),(12,'virtual','狗狗币','狗币','dt','/uploads/20250622/d4e4c026763d09d0fbf052b2cdc9de2a.jpg','/uploads/20250622/d4e4c026763d09d0fbf052b2cdc9de2a.jpg',100,1,1.0000,0,0,'{\"address\": \"xxxxxxxx\"}','2025-05-19 15:41:10','2025-06-22 14:54:08'),(13,'virtual','USTD_TRC20','USTD','ustd_trc20','/uploads/20250622/608f5e46523337fc4032de446cec6c2d.jpg','/uploads/20250622/1f6de79440574d3830a237ebf590b4ca.jpg',0,1,7.5000,0,1,'{\"sourceUrl\": \"/api/pay/getTrc20Address\"}','2025-05-19 15:41:10','2025-06-22 14:55:02');
/*!40000 ALTER TABLE `fa_bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ag.cc'
--

--
-- Dumping routines for database 'ag.cc'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-05  1:30:03
