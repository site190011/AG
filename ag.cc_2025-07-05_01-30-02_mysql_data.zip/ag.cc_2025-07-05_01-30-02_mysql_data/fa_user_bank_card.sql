-- MySQL dump 10.13  Distrib 5.7.43, for Linux (x86_64)
--
-- Host: localhost    Database: ag.cc
-- ------------------------------------------------------
-- Server version	5.7.43-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fa_user_bank_card`
--

DROP TABLE IF EXISTS `fa_user_bank_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_user_bank_card` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` int(10) unsigned NOT NULL COMMENT '关联用户ID',
  `type` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '类型 bank:银行卡,virtual:虚拟币',
  `card_number` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '卡号/虚拟币地址',
  `bank_code` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行编码',
  `card_holder` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '持卡人姓名',
  `bank_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行名称',
  `bank_name2` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '开户行',
  `expiry_date` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '有效期（MM/YY格式）',
  `cvv` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '安全码',
  `is_default` tinyint(1) DEFAULT '0' COMMENT '默认卡标记',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态（1正常 0停用）',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `delete_time` timestamp NULL DEFAULT NULL COMMENT '软删除时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_card` (`card_number`(4))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户银行卡管理表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_user_bank_card`
--

LOCK TABLES `fa_user_bank_card` WRITE;
/*!40000 ALTER TABLE `fa_user_bank_card` DISABLE KEYS */;
INSERT INTO `fa_user_bank_card` VALUES (1,2,'bank','2423423','CITIC','2423','中信银行',NULL,NULL,NULL,0,1,'2025-05-07 05:01:07','2025-05-19 14:41:45',NULL),(2,2,'bank','34534543','CITIC','444','中信银行',NULL,NULL,NULL,1,1,'2025-05-07 05:01:38','2025-06-13 05:09:33',NULL),(3,2,'third','2233','alipay','wrewrew','支付宝',NULL,NULL,NULL,1,1,'2025-05-07 10:55:18','2025-06-13 05:03:45',NULL),(4,2,'virtual','eeee',NULL,'www',NULL,NULL,NULL,NULL,1,1,'2025-05-07 14:34:26','2025-06-13 05:03:42',NULL),(5,2,'third','242342','alipay','是否水电费','支付宝',NULL,NULL,NULL,1,1,'2025-05-19 17:26:44','2025-06-13 05:03:41',NULL),(6,2,'bank','378242764723627','ICBC','nibi','中国工商银行',NULL,NULL,NULL,0,1,'2025-06-21 20:00:16','2025-06-21 20:00:16',NULL),(7,2,'virtual','sgsfsdfafafdssf','ustd_trc20','adadsa','USTD_TRC20',NULL,NULL,NULL,0,1,'2025-06-21 20:02:40','2025-06-21 20:02:40',NULL),(8,13,'bank','2432424242342','BCOM','dada','交通银行',NULL,NULL,NULL,0,1,'2025-06-22 20:20:34','2025-06-22 20:20:34',NULL),(9,13,'virtual','fsfsdfafdfasfa','ustd_trc20','dada','USTD_TRC20',NULL,NULL,NULL,0,1,'2025-06-23 17:25:52','2025-06-23 17:25:52',NULL);
/*!40000 ALTER TABLE `fa_user_bank_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ag.cc'
--

--
-- Dumping routines for database 'ag.cc'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-05  1:30:04
