-- MySQL dump 10.13  Distrib 5.7.43, for Linux (x86_64)
--
-- Host: localhost    Database: ag.cc
-- ------------------------------------------------------
-- Server version	5.7.43-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fa_user_withdraw`
--

DROP TABLE IF EXISTS `fa_user_withdraw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_user_withdraw` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '提现ID',
  `user_id` int(10) unsigned NOT NULL COMMENT '用户ID',
  `amount` decimal(10,2) unsigned NOT NULL COMMENT '提现金额',
  `status` enum('pending','processing','success','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'pending' COMMENT '提现状态',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注/失败原因',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '申请时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `process_time` timestamp NULL DEFAULT NULL COMMENT '处理完成时间',
  `type` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '类型 bank:银行卡,virtual:虚拟币',
  `card_number` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '卡号/虚拟币地址',
  `bank_code` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行编码',
  `card_holder` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '持卡人姓名',
  `bank_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行名称',
  `bank_name2` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '开户行',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户提现记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_user_withdraw`
--

LOCK TABLES `fa_user_withdraw` WRITE;
/*!40000 ALTER TABLE `fa_user_withdraw` DISABLE KEYS */;
INSERT INTO `fa_user_withdraw` VALUES (1,22,916.21,'success','','2025-05-20 17:03:07','2025-07-04 09:58:14','2025-05-20 18:01:25','bank','2423423','CITIC','2423','中信银行',NULL),(2,2,916.21,'failed','','2025-05-20 17:05:09','2025-05-20 18:01:13','2025-05-20 18:01:13','bank','2423423','CITIC','2423','中信银行',NULL),(3,2,916.21,'failed','','2025-05-20 18:05:13','2025-05-20 18:08:04','2025-05-20 18:08:04','bank','2423423','CITIC','2423','中信银行',NULL),(4,2,916.21,'failed','','2025-05-20 18:08:08','2025-05-20 18:08:34','2025-05-20 18:08:34','bank','2423423','CITIC','2423','中信银行',NULL),(5,22,916.21,'failed','','2025-05-20 18:08:40','2025-07-04 09:58:18','2025-05-20 18:10:14','bank','2423423','CITIC','2423','中信银行',NULL),(6,2,916.21,'failed','','2025-05-20 18:10:17','2025-05-20 18:12:54','2025-05-20 18:12:54','bank','2423423','CITIC','2423','中信银行',NULL),(7,2,1333.00,'failed','','2025-05-20 18:12:58','2025-05-20 18:14:26','2025-05-20 18:14:26','bank','2423423','CITIC','2423','中信银行',NULL),(8,2,222.00,'failed','','2025-05-20 18:14:46','2025-05-20 18:21:23','2025-05-20 18:21:23','bank','2423423','CITIC','2423','中信银行',NULL),(9,2,222.00,'failed','','2025-05-20 18:21:27','2025-05-20 18:21:44','2025-05-20 18:21:44','bank','2423423','CITIC','2423','中信银行',NULL),(10,2,111.00,'failed','2222222','2025-05-20 18:26:52','2025-05-20 18:27:11','2025-05-20 18:27:11','bank','2423423','CITIC','2423','中信银行',NULL),(11,2,221.00,'failed','3333','2025-05-20 18:27:25','2025-05-20 18:27:35','2025-05-20 18:27:35','bank','2423423','CITIC','2423','中信银行',NULL),(12,22,102.00,'processing',NULL,'2025-05-21 07:21:46','2025-07-04 09:58:10',NULL,'bank','2423423','CITIC','2423','中信银行',NULL),(13,13,100.00,'success','','2025-06-24 01:23:56','2025-06-24 13:45:41','2025-06-24 21:45:41','bank','2432424242342','BCOM','dada','交通银行',NULL),(14,13,100.00,'success','','2025-06-24 21:46:34','2025-06-24 13:47:17','2025-06-24 21:47:17','virtual','fsfsdfafdfasfa','ustd_trc20','dada','USTD_TRC20',NULL);
/*!40000 ALTER TABLE `fa_user_withdraw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ag.cc'
--

--
-- Dumping routines for database 'ag.cc'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-05  1:30:04
