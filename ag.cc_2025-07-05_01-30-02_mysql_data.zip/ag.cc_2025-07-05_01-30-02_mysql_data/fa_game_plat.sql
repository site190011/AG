-- MySQL dump 10.13  Distrib 5.7.43, for Linux (x86_64)
--
-- Host: localhost    Database: ag.cc
-- ------------------------------------------------------
-- Server version	5.7.43-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fa_game_plat`
--

DROP TABLE IF EXISTS `fa_game_plat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_game_plat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(32) DEFAULT NULL COMMENT 'Key',
  `name` varchar(255) DEFAULT NULL COMMENT '名字',
  `image` varchar(255) DEFAULT NULL COMMENT '图片',
  `api_scope` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `code` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_game_plat`
--

LOCK TABLES `fa_game_plat` WRITE;
/*!40000 ALTER TABLE `fa_game_plat` DISABLE KEYS */;
INSERT INTO `fa_game_plat` VALUES (1,'ag','亚游',NULL,'fetch_api_game_list'),(2,'bbin','宝盈',NULL,'fetch_api_game_list'),(3,'bg','大游',NULL,'fetch_api_game_list'),(4,'boya','博雅',NULL,'fetch_api_game_list'),(5,'cq9','CQ9',NULL,'fetch_api_game_list'),(6,'db2','多宝老虎机',NULL,'fetch_api_game_list'),(7,'db6','多宝捕鱼',NULL,'fetch_api_game_list'),(8,'db7','多宝棋牌',NULL,'fetch_api_game_list'),(9,'fc','FC',NULL,'fetch_api_game_list'),(10,'fg','FG',NULL,'fetch_api_game_list'),(11,'jdb','夺宝',NULL,'fetch_api_game_list'),(12,'joker','Joker',NULL,'fetch_api_game_list'),(13,'km','KingMaker',NULL,'fetch_api_game_list'),(14,'ky','开元',NULL,'fetch_api_game_list'),(15,'leg','乐游',NULL,'fetch_api_game_list'),(16,'lgd','LGD',NULL,'fetch_api_game_list'),(17,'mg','MG',NULL,'fetch_api_game_list'),(18,'mt','美天',NULL,'fetch_api_game_list'),(19,'mw','大满贯',NULL,'fetch_api_game_list'),(20,'nw','新世界',NULL,'fetch_api_game_list'),(21,'pg','PG',NULL,'fetch_api_game_list'),(22,'pgs','pgs',NULL,'fetch_api_game_list'),(23,'pp','王者',NULL,'fetch_api_game_list'),(24,'pt','PT',NULL,'fetch_api_game_list'),(25,'t1','T1game',NULL,'fetch_api_game_list'),(26,'vg','财神棋牌',NULL,'fetch_api_game_list'),(27,'wl','瓦力',NULL,'fetch_api_game_list'),(28,'ww','双赢',NULL,'fetch_api_game_list'),(29,'xgd','高登',NULL,'fetch_api_game_list'),(30,'yoo','云游',NULL,'fetch_api_game_list'),(31,'tf','电竞牛',NULL,'none'),(32,'db5','多宝电竞',NULL,'none'),(33,'xj','小金',NULL,'none'),(34,'ug','UG',NULL,'none'),(35,'ss','三昇',NULL,'none'),(36,'sbo','SBO',NULL,'none'),(37,'saba','沙巴',NULL,'none'),(38,'panda','熊猫体育',NULL,'none'),(39,'newbb','NewBB',NULL,'none'),(40,'im','IM',NULL,'none'),(41,'fb','FB',NULL,'none'),(42,'crown','皇冠crown',NULL,'none'),(43,'cmd','CMD',NULL,'none'),(44,'ap','平博',NULL,'none'),(45,'vr','VR',NULL,'none'),(46,'tcg','天成',NULL,'none'),(47,'sgwin','双赢',NULL,'none'),(48,'ig','IG',NULL,'none'),(49,'gw','GW',NULL,'none'),(50,'db3','多宝彩票',NULL,'none'),(51,'esb','电竞牛',NULL,'none'),(52,'cr','皇冠体育',NULL,'none');
/*!40000 ALTER TABLE `fa_game_plat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ag.cc'
--

--
-- Dumping routines for database 'ag.cc'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-05  1:30:03
