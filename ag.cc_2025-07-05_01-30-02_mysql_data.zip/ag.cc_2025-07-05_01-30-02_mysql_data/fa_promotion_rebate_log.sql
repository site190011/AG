-- MySQL dump 10.13  Distrib 5.7.43, for Linux (x86_64)
--
-- Host: localhost    Database: ag.cc
-- ------------------------------------------------------
-- Server version	5.7.43-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fa_promotion_rebate_log`
--

DROP TABLE IF EXISTS `fa_promotion_rebate_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_promotion_rebate_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '收益人uid',
  `player_uid` int(11) DEFAULT NULL COMMENT '下注人uid',
  `related_bet_ids` text COMMENT '相关的下注id列表',
  `bet_amount` decimal(10,2) DEFAULT NULL COMMENT '下注总额',
  `rebate_amount` decimal(10,2) DEFAULT NULL COMMENT '返水总额',
  `create_time` timestamp NULL DEFAULT NULL COMMENT '返水时间',
  PRIMARY KEY (`id`),
  KEY `created_time` (`create_time`),
  KEY `uid` (`user_id`),
  KEY `player_uid` (`player_uid`),
  KEY `bet_amount` (`bet_amount`),
  KEY `rebate_amount` (`rebate_amount`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_promotion_rebate_log`
--

LOCK TABLES `fa_promotion_rebate_log` WRITE;
/*!40000 ALTER TABLE `fa_promotion_rebate_log` DISABLE KEYS */;
INSERT INTO `fa_promotion_rebate_log` VALUES (1,2,5,'2,3,4,5',72.20,0.07,'2025-06-04 07:48:17'),(2,3,5,'2,3,4,5',72.20,0.22,'2025-06-04 07:48:17'),(3,4,5,'2,3,4,5',72.20,0.14,'2025-06-04 07:48:17'),(4,3,5,'1',6.00,0.02,'2025-06-04 07:48:17'),(5,4,5,'1',6.00,0.01,'2025-06-04 07:48:17'),(6,2,5,'2,3,4,5',72.20,0.07,'2025-06-04 07:50:05'),(7,3,5,'2,3,4,5',72.20,0.22,'2025-06-04 07:50:05'),(8,4,5,'2,3,4,5',72.20,0.14,'2025-06-04 07:50:05'),(9,3,5,'1',6.00,0.02,'2025-06-04 07:50:05'),(10,22,5,'1',6.00,0.01,'2025-06-04 07:50:05'),(19,2,2,'7,72,73,74,75,8,6',7940.00,79.40,'2025-06-23 18:18:36'),(20,2,2,'11,12,84,83,82,81,80,79,78,77,76,9,10',66.66,0.67,'2025-06-23 18:18:36'),(21,22,13,'102,101,87,100,99,98,97,96,95,94,93,92,91,90,89,88,86,85',6581.00,65.81,'2025-06-23 18:18:36'),(22,13,13,'103,104',7950.00,79.50,'2025-06-23 18:18:36'),(23,2,2,'105,106,107,108',48.50,0.49,'2025-06-24 00:12:02'),(24,2,2,'109,110,111',15.00,0.15,'2025-06-24 14:50:02'),(25,2,2,'112',5.00,0.05,'2025-06-24 14:52:02');
/*!40000 ALTER TABLE `fa_promotion_rebate_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ag.cc'
--

--
-- Dumping routines for database 'ag.cc'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-05  1:30:03
