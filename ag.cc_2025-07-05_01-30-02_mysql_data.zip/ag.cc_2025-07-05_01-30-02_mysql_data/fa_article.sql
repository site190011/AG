-- MySQL dump 10.13  Distrib 5.7.43, for Linux (x86_64)
--
-- Host: localhost    Database: ag.cc
-- ------------------------------------------------------
-- Server version	5.7.43-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fa_article`
--

DROP TABLE IF EXISTS `fa_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `type` varchar(32) DEFAULT NULL COMMENT '类型',
  `type2` varchar(64) NOT NULL DEFAULT '',
  `author` varchar(100) DEFAULT NULL COMMENT '作者',
  `content` text NOT NULL COMMENT '内容',
  `views` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数',
  `status` enum('draft','published','deleted') NOT NULL DEFAULT 'draft' COMMENT '状态',
  `weigh` int(11) NOT NULL DEFAULT '0' COMMENT '权重',
  `publishtime` int(11) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `createtime` int(11) DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(11) DEFAULT NULL COMMENT '更新时间',
  `coverimage` varchar(255) DEFAULT NULL COMMENT '封面图',
  `description` text COMMENT '摘要',
  `tags` varchar(255) DEFAULT NULL COMMENT '标签',
  `jumplink` varchar(255) DEFAULT NULL,
  `is_top` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type2` (`type2`),
  KEY `type` (`type`),
  KEY `tags` (`tags`),
  KEY `is_top` (`is_top`),
  KEY `status` (`status`),
  KEY `title` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='文章表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_article`
--

LOCK TABLES `fa_article` WRITE;
/*!40000 ALTER TABLE `fa_article` DISABLE KEYS */;
INSERT INTO `fa_article` VALUES (1,'提现提示','noticeRoll','','2','<p>沙发发</p>',0,'published',1,1745416427,1745416501,1746382362,'/uploads/20250423/bb35f50a1bba5f1c915d7101143553dd.jpg','滚动公告舒服点','呃呃','',NULL),(2,'标题2','notice','events_recharge',NULL,'<p>胜多负少</p>',0,'published',2,1745416556,1745416600,1750524404,'/uploads/20250622/7990ea284cabdd657889ebb197452f0b.png','沃尔沃二','问问','',NULL),(3,'活动','events','events_recharge',NULL,'<p>活动活动活动活动活动</p><p><br></p><p>活<font color=\"#000000\" style=\"background-color: rgb(255, 255, 0);\">动活动活动活动活</font>动活动</p><p><br></p><p>活动活动活动活动活动活动</p><p><br></p><p>活动活动活动活动活动活动</p><p><br></p><p>活动活动活动活动活动活动</p><p><br></p><p>活动活动活动活动活动活动</p><p><br></p><p>活动活动活动活<b><u>动活动活动</u></b></p><p><br></p><p>活动活动活动活动活动活动</p><p><br></p><p>活动活<font color=\"#000000\" style=\"background-color: rgb(255, 255, 0);\">动活动活动活动活动</font></p><p><font color=\"#000000\" style=\"background-color: rgb(255, 255, 0);\"><br></font></p><p><font color=\"#000000\" style=\"background-color: rgb(255, 255, 0);\">活动活动活动活动活动活动</font></p><p><br></p><p>活动活动活动活动活动活动</p><p><br></p><p>活动活动活动活动活动活动</p><p><br></p><p>活动活动活动活动活动活动</p><p><br></p><p>活动活<font color=\"#000000\" style=\"background-color: rgb(255, 255, 0);\">动活动活动活</font>动活动</p><p><br></p><p>活动活动活动活动活动活动</p><p><br></p><p>活动</p>',0,'published',3,1746368125,1746368152,1750015190,'/uploads/20250616/bc914ee36cdbb46f88e6408db9df1b84.png','','[\"1\",\"2\",\"345555\",\"sdd\"]','',NULL),(4,'教程','manual','',NULL,'<p>教程教程教程教程教程</p>',0,'published',4,1746368156,1746368170,1746373085,'','','','',NULL),(5,'新闻1','news','',NULL,'<p>新闻1新闻1新闻1</p><p>新闻1</p><p>新闻1</p><hr><p>新闻1</p><p>新闻1新闻1新闻1</p><p><br></p><p>新闻1</p>',0,'published',5,1746442815,1746442843,1746442867,'','','','',NULL),(6,'每日首充','events','events_recharge',NULL,'<p><font color=\"#ffffff\">每日首充任务</font></p><p><font color=\"#ffffff\">活动时间:长期有效</font></p><p><font color=\"#ffffff\"><br></font></p><p><font color=\"#ffffff\">简介:</font></p><p><font color=\"#ffffff\">根据充值金额自动赠送不同金额的奖励最高赠送88U</font></p><p><font color=\"#ffffff\">嘉奖明细:</font></p><p><font color=\"#ffffff\"><br></font></p><table class=\"table table-bordered\"><tbody><tr><td><font color=\"#ffffff\">档位</font></td><td><font color=\"#ffffff\">充值</font></td><td><font color=\"#ffffff\">赠送金额</font></td><td><font color=\"#ffffff\">流水要求</font></td></tr><tr><td><font color=\"#ffffff\">1</font></td><td><h2 class=\"\" style=\"border: 0px; border-collapse: collapse; border-spacing: 0px; list-style: none; margin: 0px; padding: 0px; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; font-size-adjust: none; font-kerning: auto; font-optical-sizing: auto; font-feature-settings: normal; font-variation-settings: normal; font-variant-position: normal; font-variant-emoji: normal; font-stretch: normal; font-size: 20px; line-height: 28px; font-family: Arial, Helvetica, sans-serif;\"><span style=\"font-size: 14px;\"><font color=\"#ffffff\">≥100u</font></span></h2></td><td><font color=\"#ffffff\">8</font></td><td><font color=\"#ffffff\"><br></font></td></tr><tr><td><font color=\"#ffffff\">2</font></td><td><span style=\"font-family: Arial, Helvetica, sans-serif;\"><font color=\"#ffffff\">≥500u</font></span></td><td><font color=\"#ffffff\">28</font></td><td><font color=\"#ffffff\"><br></font></td></tr><tr><td><font color=\"#ffffff\">3</font></td><td><span style=\"font-family: Arial, Helvetica, sans-serif;\"><font color=\"#ffffff\">≥1000u</font></span></td><td><font color=\"#ffffff\">68</font></td><td><font color=\"#ffffff\">(本金+彩金)3倍流水</font></td></tr><tr><td><font color=\"#ffffff\">4</font></td><td><span style=\"font-family: Arial, Helvetica, sans-serif;\"><font color=\"#ffffff\">≥2000u</font></span></td><td><font color=\"#ffffff\">118</font></td><td><font color=\"#ffffff\"><br></font></td></tr><tr><td><font color=\"#ffffff\">5</font></td><td><span style=\"font-family: Arial, Helvetica, sans-serif;\"><font color=\"#ffffff\">≥5000u</font></span></td><td><font color=\"#ffffff\">258</font></td><td><font color=\"#ffffff\"><br></font></td></tr><tr><td><font color=\"#ffffff\">6</font></td><td><span style=\"font-family: Arial, Helvetica, sans-serif;\"><font color=\"#ffffff\">≥10000u</font></span></td><td><font color=\"#ffffff\">588</font></td><td><font color=\"#ffffff\"><br></font></td></tr></tbody></table><p><font color=\"#ffffff\">活动规则:</font></p><p><font color=\"#ffffff\">1.充值每日首充活动，需完成额外的附件流水方可提现。例如:充值200U，领取8U奖励，需完成对应档位(100U)本金加彩金的3倍流水，即 324的消费流水;</font></p><p><font color=\"#ffffff\"><br></font></p><p><font color=\"#ffffff\">注:当日提现后就不能参加每日首充活动2.此活动只适用于拥有一个账号的会员;每个设备每个telegram、每个支付方式、每个IP地址只享受一次，恶意刷单，平台有权不给与奖励;3.为避免文字上的理解差异，平台保持对本活动的最终解释权，并且有权更换推迟或取消活动。</font></p>',0,'published',6,1750015108,1750015149,1750552949,'/uploads/20250621/443c0a35d7f418f400338c0ce72928fb.webp','','','',NULL);
/*!40000 ALTER TABLE `fa_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ag.cc'
--

--
-- Dumping routines for database 'ag.cc'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-05  1:30:03
